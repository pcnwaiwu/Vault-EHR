---
name: Security Finding
about: Document a security finding from assessment or continuous monitoring
title: "[FINDING] "
labels: "status:open"
---

## Finding Details

**Finding ID:** FIND-XXX  
**Control ID:** (e.g., AC-2, IA-2(1))  
**Control Family:** (e.g., Access Control)  
**Severity:** <!-- Critical / High / Moderate / Low -->  
**Status:** Open  
**Identified By:** <!-- 3PAO / ISSO / Scan / Audit -->  
**Date Identified:**  

---

## Description

<!-- Clear description of the finding. What is the gap? What was observed? -->

---

## Evidence

<!-- What evidence supports this finding? Screenshots, log snippets, scan output, etc. -->

---

## Impact

**Likelihood:** <!-- High / Moderate / Low -->  
**Impact:** <!-- High / Moderate / Low -->  
**Risk Rating:** <!-- Critical / High / Moderate / Low -->

<!-- Describe what could happen if this finding is exploited or not remediated -->

---

## Recommended Remediation

<!-- Step-by-step remediation actions -->

---

## Compensating Controls (if any)

<!-- Are any compensating controls currently in place? -->

---

## Remediation Target Date

**Target:**  
**Assigned To:**  
**POA&M Item:** POA&M-XXX
