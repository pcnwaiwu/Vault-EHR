---
name: POA&M Item
about: Track a Plan of Action and Milestones item
title: "[POA&M] "
labels: "status:open"
---

## POA&M Item Details

**POA&M ID:** POA-XXX  
**Finding Reference:** FIND-XXX  
**Control ID:**  
**Severity:**  
**Status:** Open  
**Responsible Party:**  
**Due Date:**  

---

## Weakness Description

<!-- Brief description of the weakness this POA&M item addresses -->

---

## Milestones

- [ ] **Milestone 1:** [Description] — Due: [Date]
- [ ] **Milestone 2:** [Description] — Due: [Date]
- [ ] **Milestone 3:** Verification and evidence collection — Due: [Date]

---

## Resources Required

**Labor:**  
**Cost:**  
**Approvals Needed:**  

---

## Compensating Controls

<!-- What compensating controls are in place while remediation is in progress? -->

---

## Completion Criteria

<!-- How will we know this is done? What evidence is required? -->

---

## Monthly Status Updates

| Date | Status | Notes | Updated By |
|------|--------|-------|-----------|
| | | | |
